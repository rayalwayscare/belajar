# Brutal Spam SCW
```
Tools ini dibuat untuk nyepam temen, mantan,
sama kang tipu pasti auto minta ampun dah :v
```
> Script ini sewaktu-waktu bisa jadi limit ataupun coid jadi jangan salahin author nya ya goblok.
## How to it?
```php
$ cd Brutal-SCW
$ pip install -r requirements.txt
$ python spam.py
```
> Get Token [click here](https://cutt.ly/TokenBrutalScw)
## Support Me On
<b>• [Facebook](https://m.facebook.com/dhasilva.junior.3)</b>
<br>
<b>• [Youtube](https://www.youtube.com/channel/UCLRXFyMN0L8yH9F-xxOd7Og)</b>
</br>
